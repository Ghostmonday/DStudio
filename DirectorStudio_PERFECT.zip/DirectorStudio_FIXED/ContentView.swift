import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("DirectorStudio")
            .padding()
    }
}

#Preview {
    ContentView()
}
